//
//  Z_MetronomeApp.swift
//  Z-Metronome
//
//  Created by Zane Kuchera on 1/27/26.
//

import SwiftUI

@main
struct Z_MetronomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
