//
//  Z_MetronomeApp.swift
//  Z-Metronome Watch App
//
//  Created by Zane Kuchera on 1/27/26.
//

import SwiftUI

@main
struct Z_Metronome_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
